package com.github.kevinsawicki.http;

import java.io.DataOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;

public class Main2014302580168 {

	public Main2014302580168() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
      String url="http://staff.whu.edu.cn/show.jsp?lang=cn&n=Liu%20Chuan%20Jun";//��ַ
		File out=new File("F:/workspace/OOP-JAVA/zhuye.html");//������ҳ
		HttpRequest response =  HttpRequest.get( url);
		response.receive(out);//��ȡ��ҳ������
		
		Document doc=Jsoup.parse(out, null, url);//������ҳ
		//Element link =doc.getElementById("content");
		Elements links =doc.getElementsByTag("p");
		Elements link =doc.getElementsByTag("h3");
	
	//String regex="^\\w+([-+.]\\w+)*@\\w+([-.]\\w+)*\\.\\w+([-.]\\w+)*";//��������

	//	Elements email =doc.select("p:matchesOwn(��^\\w+([-+.]\\w+)*@\\w+([-.]\\w+)*\.\\w+([-.]\\w+)*$��);
	File outputfile=new File("F:/workspace/OOP-JAVA/output.txt");
	FileOutputStream file= new FileOutputStream(outputfile);
		DataOutputStream output= new DataOutputStream(file);
		output.writeUTF(link.text());
		output.writeChars("\n");
	//if(links.text().matches(regex))
		output.writeUTF(links.text());
		output.close();
		
		
	}
	
}
